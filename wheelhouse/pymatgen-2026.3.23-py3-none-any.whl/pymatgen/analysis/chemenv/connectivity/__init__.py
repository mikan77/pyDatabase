"""Package for analyzing connectivity."""
